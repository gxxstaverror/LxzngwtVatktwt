Site criado para deploy no Netlify.
Conteúdo:
- index.html
- styles.css
- netlify.toml

Como usar:
1. Descompacte o zip.
2. Faça deploy na Netlify: arraste a pasta para a área de deploy ou conecte o repositório.
